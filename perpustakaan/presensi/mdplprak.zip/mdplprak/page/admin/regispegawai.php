<?php
include"../../config.php";
mysqli_query($con,"INSERT into buku set username='$username',nama='$nama',`password`='$password',tempat lahir='$tempat_lahir',tanggal lahir='$tanggal_lahir',alamat='$alamat', jenis_kelamin='$jeniskelamin',tahun_masuk='$tahunmasuk',divisi='$divisi',jabatan='$jabatan',gambar='$nama_file_baru'");
                
                move_uploaded_file($_FILES['gambar']['tmp_name'], '../../gambar/'.$nama_file_baru);
                header("location:registrasi.php");


?>