<?php
include"../../config.php";
session_start();
$id_presensi = $_SESSION['id_presensi'];
$nip = $_POST['username'];
$nama = $_POST['nama'];
$tanggal = $_POST['tanggal'];
$absen = $_POST['absen'];
if (mysqli_query($con,"INSERT INTO presensi set id_presensi='$id_presensi',nama='$nama',tanggal='$tanggal',nip='$username',absen='absen'")) {
  $last_id = mysqli_insert_id($con);
}
header("location:index.php?page=kehadiran");
?>