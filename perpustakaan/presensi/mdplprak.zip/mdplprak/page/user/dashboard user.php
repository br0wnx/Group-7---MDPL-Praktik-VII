<?php
include"../../config.php";
session_start();
if(!isset($_SESSION['username']))
{
	header("location:../../login.php");
}
$nama = $_SESSION['nama'];
?>
<!DOCTYPE html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Admin</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Google Fonts
    ============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700,900" rel="stylesheet">
    <!-- Bootstrap CSS
    ============================================ -->
    <link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
    <!-- Bootstrap CSS
    ============================================ -->
    <link rel="stylesheet" href="../../assets/css/font-awesome.min.css">
    <!-- nalika Icon CSS
    ============================================ -->
    <link rel="stylesheet" href="../../assets/css/nalika-icon.css">
    <!-- owl.carousel CSS
    ============================================ -->
    <link rel="stylesheet" href="../../assets/css/owl.carousel.css">
    <link rel="stylesheet" href="../../assets/css/owl.theme.css">
    <link rel="stylesheet" href="../../assets/css/owl.transitions.css">
    <!-- animate CSS
    ============================================ -->
    <link rel="stylesheet" href="../../assets/css/animate.css">
    <!-- normalize CSS
    ============================================ -->
    <link rel="stylesheet" href="../../assets/css/normalize.css">
    <!-- meanmenu icon CSS
    ============================================ -->
    <link rel="stylesheet" href="../../assets/css/meanmenu.min.css">
    <!-- main CSS
    ============================================ -->
    <link rel="stylesheet" href="../../assets/css/main.css">
    <!-- morrisjs CSS
    ============================================ -->
    <link rel="stylesheet" href="../../assets/css/morrisjs/morris.css">
    <!-- mCustomScrollbar CSS
    ============================================ -->
    <link rel="stylesheet" href="../../assets/css/scrollbar/jquery.mCustomScrollbar.min.css">
    <!-- metisMenu CSS
    ============================================ -->
    <link rel="stylesheet" href="../../assets/css/metisMenu/metisMenu.min.css">
    <link rel="stylesheet" href="../../assets/css/metisMenu/metisMenu-vertical.css">
    <!-- calendar CSS
    ============================================ -->
    <link rel="stylesheet" href="../../assets/css/calendar/fullcalendar.min.css">
    <link rel="stylesheet" href="../../assets/css/calendar/fullcalendar.print.min.css">
    <!-- style CSS
    ============================================ -->
    <link rel="stylesheet" href="../../assets/css/style.css">
    <!-- responsive CSS
    ============================================ -->
    <link rel="stylesheet" href="../../assets/css/responsive.css">
    <!-- modernizr JS
    ============================================ -->
    <script src="../../assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
        <div class="left-sidebar-pro">
            <nav id="sidebar" class="">
                <div class="sidebar-header">
                    <a href="dashboard user.html"><h3>PT. MAKMUR JAYA</h3></a>
                </div>
                <div class="nalika-profile">
                    <div class="profile-dtl">
                        <a href="#"><img src="download.jpg" alt="" /></a>
                        <h2> <span class="min-dtn"><?= $nama ?></span></h2>
                        <h2> <span class="min-dtn"><?= $nip ?></span></h2>
                    </div>
                </div>
                <div class="left-custom-menu-adp-wrap comment-scrollbar">
                    <nav class="sidebar-nav left-sidebar-menu-pro">
                        <ul class="metismenu" id="menu1">
                            <li>
                                <a href="index.php?page=presensi">Presensi</a>
                            </li>
                            <li>
                                <a href="index.php?page=kehadiran">Daftar Hadir</a>
                            </li>
                            <li>
                                <a href="../../masuk.html">Logout</a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </nav>
        </div>
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="product-list.html"><img class="main-logo" src="../../assets/img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-advance-area">
            <div class="header-top-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="header-top-wraper">
                                <h2 style="padding: 50px; text-align: center; color: whitesmoke;">DASHBOARD</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- main -->
            <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                    </div>
                </div>
            </div>
        </div>
        <div class="product-status mg-b-30">
            <div class="container-fluid">
                        <?php
                          if(isset($_GET['page'])) {
                            $page = $_GET['page'] . ".php";
                            include ("$page");

                          } else {
                            include ('biodata.php');
                          }?>
            </div>
        </div>
        <div class="footer-copyright-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="footer-copy-right">
                            <p>Team 7 © 2021 All Rights Reserved | <a href="#">MDPL Praktik VII</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- jquery
    ============================================ -->
    <script src="../../assets/js/vendor/jquery-1.12.4.min.js"></script>
    <!-- bootstrap JS
    ============================================ -->
    <script src="../../assets/js/bootstrap.min.js"></script>
    <!-- wow JS
    ============================================ -->
    <script src="../../assets/js/wow.min.js"></script>
    <!-- price-slider JS
    ============================================ -->
    <script src="../../assets/js/jquery-price-slider.js"></script>
    <!-- meanmenu JS
    ============================================ -->
    <script src="../../assets/js/jquery.meanmenu.js"></script>
    <!-- owl.carousel JS
    ============================================ -->
    <script src="../../assets/js/owl.carousel.min.js"></script>
    <!-- sticky JS
    ============================================ -->
    <script src="../../assets/js/jquery.sticky.js"></script>
    <!-- scrollUp JS
    ============================================ -->
    <script src="../../assets/js/jquery.scrollUp.min.js"></script>
    <!-- mCustomScrollbar JS
    ============================================ -->
    <script src="../../assets/js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
    <script src="../../assets/js/scrollbar/mCustomScrollbar-active.js"></script>
    <!-- metisMenu JS
    ============================================ -->
    <script src="../../assets/js/metisMenu/metisMenu.min.js"></script>
    <script src="../../assets/js/metisMenu/metisMenu-active.js"></script>
    <!-- morrisjs JS
    ============================================ -->
    <script src="../../assets/js/sparkline/jquery.sparkline.min.js"></script>
    <script src="../../assets/js/sparkline/jquery.charts-sparkline.js"></script>
    <!-- calendar JS
    ============================================ -->
    <script src="../../assets/js/calendar/moment.min.js"></script>
    <script src="../../assets/js/calendar/fullcalendar.min.js"></script>
    <script src="../../assets/js/calendar/fullcalendar-active.js"></script>
    <!-- plugins JS
    ============================================ -->
    <script src="../../assets/js/plugins.js"></script>
    <!-- main JS
    ============================================ -->
    <script src="../../assets/js/main.js"></script>
</body>

</html>